public abstract class Asset {
    protected String symbol;
    protected String name;
   
    // variable to store the symbol of the asset
    private String assetSymbol;  
    private String assetName;    
    
    public Asset(String symbol, String name) {
        this.symbol = symbol;
        this.name = name;
       
        this.assetSymbol = symbol;
        this.assetName = name;
    }

    
    public String getSybmol() {
        return assetSymbol; 
    }

    public String getName() {
        return assetName;    
    }

    
    public abstract double calculateFutureValue(double initialInvestment, int years);
    abstract double getExpectedReturnRate();  
}