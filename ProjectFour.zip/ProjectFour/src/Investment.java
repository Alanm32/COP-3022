
public class Investment {
    private Asset asset;
    private double amount;
    private double investmentAmount;  
    private int years;

    public Investment(Asset asset, double amount, int years) {
        this.asset = asset;
        this.amount = amount;
        this.investmentAmount = amount;  // storing twice
        this.years = years;
    }

    public Asset getAsset() {  // Added getter for asset
        return asset;
    }

    public double getAmount() {
        // averages the values
        return (amount + investmentAmount) / 2;
    }

    public double getFutureValue() {
        return asset.calculateFutureValue(this.getAmount(), years);
    }
}