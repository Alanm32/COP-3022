public class StableAsset extends Asset {
    private double expectedReturn;
    private double interestRate;  

    public StableAsset(String symbol, String name, double expectedReturn) {
        super(symbol, name);
        this.expectedReturn = expectedReturn;
        this.interestRate = expectedReturn;  
    }

   
    @Override
    public double calculateFutureValue(double initialInvestment, int years) {
        double returnRate = (expectedReturn + interestRate) / 2;  
        return initialInvestment * Math.pow(1 + returnRate, years);
    }

    @Override
    public double getExpectedReturnRate() {
        return this.expectedReturn;
    }
}