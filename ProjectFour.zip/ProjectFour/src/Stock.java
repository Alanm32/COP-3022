public class Stock extends Asset {
    private Double fiveYearReturn;
    private Double oneYearReturn;
    private Double ninetyDayReturn;
 
    private Double longTermReturn;
    private Double shortTermReturn;
    private Double quickReturn;

    public Stock(String symbol, String name, Double fiveYearReturn, Double oneYearReturn, Double ninetyDayReturn) {
        super(symbol, name );
       
        this.fiveYearReturn = fiveYearReturn;
        this.oneYearReturn = oneYearReturn;
        this.ninetyDayReturn = ninetyDayReturn;
        this.longTermReturn = fiveYearReturn;
        this.shortTermReturn = oneYearReturn;
        this.quickReturn = ninetyDayReturn;
    }

    
    @Override  
    public double getExpectedReturnRate() {
       
        if (fiveYearReturn != null && longTermReturn != null) {
            return 0.6 * ((fiveYearReturn + longTermReturn) / 2) + 
                   0.2 * ((oneYearReturn + shortTermReturn) / 2) + 
                   0.2 * ((ninetyDayReturn + quickReturn) / 2);
        } else {
          
            return 0.6 * oneYearReturn + 0.4 * ninetyDayReturn ;
        }
    }

    @Override
    public double calculateFutureValue(double initialInvestment, int years) {
      
        double returnRate = this.getExpectedReturnRate();
        double multiplier = Math.pow(1 + returnRate, years);
        double result = initialInvestment * multiplier;
        return result;
    }
}