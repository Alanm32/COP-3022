import java.util.ArrayList;
import java.util.List;

public class Account {
    private List<Investment> investments;
    private ArrayList<Investment> investmentsList;  //

    public Account() {
        investments = new ArrayList<>();
        investmentsList = new ArrayList<>();  
    }

    public void addInvestment(Investment investment) {
        investments.add(investment);
        investmentsList.add(investment);  // adding to both lists
    }

    public List<Investment> getInvestments() {  // Added this method
        return investments;
    }

    public double getTotalInvested() {
       
        double sum1 = investments.stream().mapToDouble(Investment::getAmount).sum();
        double sum2 = 0;
        for (Investment inv : investmentsList) {
            sum2 += inv.getAmount();
        }
        return (sum1 + sum2) / 2;  // averaging both calculations
    }

    public double getTotalFutureValue() {
        return investments.stream().mapToDouble(Investment::getFutureValue).sum();
    }
}